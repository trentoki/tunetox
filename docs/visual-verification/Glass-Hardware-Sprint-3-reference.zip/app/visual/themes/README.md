# TuneTox visual themes

Theme styles belong in this folder, separate from mixer layout and behavior.
Copy a theme folder to create a new reskin, then add its name and stylesheet
to the registry in `theme-manager.js`. Do not edit audio or behavior modules.

A theme should style existing semantic selectors (for example `.deck`,
`input[type="range"]`) and use `var(--accent)` for the deck color.
Colors are assigned per deck by the theme manager. Theme files should not
change input ranges, event handlers, audio gain, or transport behavior.

The Default theme is the existing `app/visual/mixer/playback.css`.
Plasma is an initial, deliberately modest reskin. Advanced plasma slider
effects are a later visual task.

Glass Hardware is an experimental reskin with recessed glass waveform windows,
machined knob rims and single native metallic slider caps. Select **Glass Hardware**
in the application's **Visual theme** menu; existing deck colors and One color
mode also apply. Its [stylesheet](glass-hardware/theme.css) changes presentation
only and is removed when another theme is selected. Default and Plasma styles
remain unchanged. No theme preference is saved across page reloads.

Glass Hardware also includes an isolated [visual cue prototype](glass-hardware/cue-preview.js).
After loading a song, tap an off-white pad to latch its deck-colored illumination.
Tap **Shift** once to enable clearing mode, then tap an assigned pad to clear it;
tap Shift again to exit. These are simulated assignments only: no cue times,
seeking, audio changes or persistence. Each deck retains its preview through view
and theme changes, and clears it when its loaded-song reference changes. Other
themes restore the original disabled cue/Shift previews. The shared Visual host
only installs/renders this preview; the theme manager announces theme changes.
The prototype declines installation if these controls already have real behavior.
Run [focused visual checks](../../../tests/glass-hardware-tests.html) through the local server.

The "Control colors (future)" mode currently uses per-deck colors until
per-control color roles are implemented.
