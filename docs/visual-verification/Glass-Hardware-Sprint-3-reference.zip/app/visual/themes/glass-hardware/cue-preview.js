// Glass Hardware prototype ONLY. No cue times, transport calls or shared state.
// The host supplies its loaded-song reference; we never modify that song.
export function installGlassCuePreview(cues, getSong) {
  const pads = [...cues.querySelectorAll('.cue-pad')];
  const shift = cues.querySelector('.loop-controls button:last-child');
  // Never take ownership if Shift or pads acquire real functionality later.
  if (!shift?.disabled || pads.some(pad => !pad.disabled)) return () => {};
  const controls = [...pads, shift];
  const originals = controls.map(control => ({ text: control.textContent,
    title: control.title, label: control.getAttribute('aria-label') }));
  const assigned = new Set();
  let song = null, shifted = false;
  const active = () => document.documentElement.dataset.theme === 'glass-hardware';

  function render() {
    const loaded = getSong();
    if (loaded !== song) { song = loaded; assigned.clear(); shifted = false; }
    controls.forEach((control, index) => {
      const pad = index < pads.length;
      const selected = pad ? assigned.has(control.dataset.cue) : shifted;
      control.disabled = !active() || !loaded;
      control.textContent = active() && pad ? control.dataset.cue : originals[index].text;
      control.title = active()
        ? (!loaded ? 'Load a song to try the visual cue preview' :
          pad ? 'Visual preview only — Shift + tap clears; no seeking' : 'Visual preview: tap to toggle clearing mode')
        : originals[index].title;
      control.setAttribute('aria-label', active()
        ? (pad ? 'Cue ' + control.dataset.cue + (selected ? ' assigned' : ' empty') + ' (visual preview)' : 'Shift clear mode (visual preview)')
        : originals[index].label);
      if (active()) control.setAttribute('aria-pressed', String(selected));
      else control.removeAttribute('aria-pressed');
    });
    shift.classList.toggle('glass-preview-shift', active());
  }

  cues.addEventListener('click', event => {
    if (!active() || !getSong()) return;
    const target = event.target.closest('button');
    if (target === shift) shifted = !shifted;
    else if (pads.includes(target)) {
      if (shifted) assigned.delete(target.dataset.cue);
      else assigned.add(target.dataset.cue);
    } else return;
    render();
  });
  // Four persistent deck views subscribe once. Theme changes restore original
  // disabled controls, labels and styling in Default/Plasma, retaining previews.
  document.addEventListener('tunetox-theme-change', render);
  return render;
}
